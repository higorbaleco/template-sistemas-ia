# Product Playbooks

Cada linha comercial deve ter seu próprio conjunto de configurações, sem duplicar a infraestrutura central.

## Estrutura recomendada

```text
ICP.md
PAINS.md
OFFER.md
QUALIFICATION.md
SCRIPTS.md
OBJECTIONS.md
CASES.md
PRICING.md
CADENCE.md
```

## Produtos

- AI
- INFRA
- DISPAROS
- ATIVOS
- PARTNERS
- SUPPLIERS
